package com.alura.literalura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibroracleApplicationTests {

	@Test
	void contextLoads() {
	}

}
