package com.alura.literalura.dto;

public record AutorDTO(
        Long Id,
        String nombre,
        int nacimiento,
        int deceso) {
}
